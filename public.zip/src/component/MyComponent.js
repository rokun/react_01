import React from 'react';
import { Button } from '@adobe/react-spectrum';

function MyComponent() {
  return (
    <div className='mama'>
      <Button variant="cta">Click me</Button>
    </div>
  );
}

export default MyComponent;